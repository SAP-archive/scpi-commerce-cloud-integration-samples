/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.xml.MarkupBuilder;
def Message processData(Message message) {
    
    def properties = message.getProperties() as Map<String, Object>;
    def jsonSlurper = new JsonSlurper().parseText(properties.get("products"));
    def index = properties.get("commerceImportLoopIndex");
    message.setProperty("commerceImportLoopIndex", index+1);

    //Get the product by index
    def product = jsonSlurper.bottomlines.get(index);
    def writer = new StringWriter()
    
    //Build the xml request body
    def xmlBuilder = new MarkupBuilder(writer);
    xmlBuilder.Products {
        Product {
            code(product.domain_key)
            reviewRating(product.product_score)
            reviewCount(product.total_reviews)
            catalogVersion {
                CatalogVersion {
                    catalog {
                        Catalog {
                            id(properties.get("catalogId"))    
                        }
                    }
           	        version ("Online")    
                }
            }            
        }   
    }
    
    message.setBody(writer.toString())

    return message;
}