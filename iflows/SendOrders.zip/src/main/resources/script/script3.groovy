/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
def Message processData(Message message) {

    message.setHeader("Content-Type", "application/json; charset=utf-8");

    def properties = message.getProperties() as Map<String, Object>;
    def body = message.getBody(java.lang.String) as String;
    
    def oAuthSlurper = new JsonSlurper().parseText(body);
    def orderPayload = properties.get("ReceivedPayload");
    def ordersSlurper = new XmlSlurper().parseText(orderPayload.trim());
    def storefrontUrl = properties.get("storefrontUrl");
    
    def builder = new groovy.json.JsonBuilder()
    builder {
        validate_data 'true'
        platfom 'general'
        utoken oAuthSlurper.access_token
        email ordersSlurper.Order.user.User.uid.text()
        customer_name ordersSlurper.Order.user.User.name.text()
        order_id ordersSlurper.Order.code.text()
        order_date ordersSlurper.Order.date.text()
        currency_iso ordersSlurper.Order.currency.Currency.isocode.text()
        products {
            ordersSlurper.Order.entries.OrderEntry.each {entry ->
                "$entry.product.Product.code" {
                    url storefrontUrl+"/p/"+"$entry.product.Product.code"
                    name "$entry.product.Product.name"            
                    description "$entry.product.Product.description"
                    price "$entry.basePrice"
                    image storefrontUrl+"$entry.product.Product.picture.Media.URL"
                }
            }
        }
    }
    
    message.setBody(builder.toString());
    return message;
}